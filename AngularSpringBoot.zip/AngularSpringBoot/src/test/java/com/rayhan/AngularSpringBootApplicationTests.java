package com.rayhan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
